-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             11.3.0.6295
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table alta_online_shop.operators
CREATE TABLE IF NOT EXISTS `operators` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.operators: ~5 rows (approximately)
/*!40000 ALTER TABLE `operators` DISABLE KEYS */;
REPLACE INTO `operators` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'telkomsel', '2022-03-16 16:37:58', '2022-03-16 16:38:00'),
	(2, 'indosat', '2022-03-16 16:38:01', '2022-03-16 16:38:01'),
	(3, 'axiata', NULL, NULL),
	(4, 'byu', NULL, NULL),
	(5, 'tri', NULL, NULL);
/*!40000 ALTER TABLE `operators` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.payment_methods
CREATE TABLE IF NOT EXISTS `payment_methods` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.payment_methods: ~3 rows (approximately)
/*!40000 ALTER TABLE `payment_methods` DISABLE KEYS */;
REPLACE INTO `payment_methods` (`id`, `name`, `status`, `created_at`, `updated_at`) VALUES
	(1, 'gopay', NULL, NULL, NULL),
	(2, 'e-banking', NULL, NULL, NULL),
	(3, 'qris', NULL, NULL, NULL);
/*!40000 ALTER TABLE `payment_methods` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.products
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `product_type_id` int(11) DEFAULT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_type_id` (`product_type_id`),
  KEY `operator_id` (`operator_id`),
  CONSTRAINT `products_ibfk_1` FOREIGN KEY (`product_type_id`) REFERENCES `product_types` (`id`),
  CONSTRAINT `products_ibfk_2` FOREIGN KEY (`operator_id`) REFERENCES `operators` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.products: ~8 rows (approximately)
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
REPLACE INTO `products` (`id`, `product_type_id`, `operator_id`, `code`, `name`, `status`, `created_at`, `updated_at`) VALUES
	(1, 1, 3, NULL, 'product dummy', NULL, NULL, NULL),
	(2, 1, 3, NULL, 'pulsa 20k', NULL, NULL, NULL),
	(3, 2, 1, NULL, 'kuota 50gb', NULL, NULL, NULL),
	(4, 2, 1, NULL, 'kuota 20gb', NULL, NULL, NULL),
	(5, 2, 1, NULL, 'kuota 100gb', NULL, NULL, NULL),
	(6, 3, 4, NULL, 'instagram 5gb', NULL, NULL, NULL),
	(7, 3, 4, NULL, 'whatsapp 2gb', NULL, NULL, NULL),
	(8, 3, 4, NULL, 'line 10gb', NULL, NULL, NULL);
/*!40000 ALTER TABLE `products` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.product_descriptions
CREATE TABLE IF NOT EXISTS `product_descriptions` (
  `id` int(11) NOT NULL,
  `description` text,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.product_descriptions: ~0 rows (approximately)
/*!40000 ALTER TABLE `product_descriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_descriptions` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.product_types
CREATE TABLE IF NOT EXISTS `product_types` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.product_types: ~3 rows (approximately)
/*!40000 ALTER TABLE `product_types` DISABLE KEYS */;
REPLACE INTO `product_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
	(1, 'pulsa', NULL, NULL),
	(2, 'kuota', NULL, NULL),
	(3, 'topping', NULL, NULL);
/*!40000 ALTER TABLE `product_types` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.transactions
CREATE TABLE IF NOT EXISTS `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `payment_methods_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `total_qty` int(11) DEFAULT NULL,
  `total_price` decimal(25,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `payment_methods_id` (`payment_methods_id`),
  CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`payment_methods_id`) REFERENCES `payment_methods` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.transactions: ~12 rows (approximately)
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
REPLACE INTO `transactions` (`id`, `user_id`, `payment_methods_id`, `status`, `total_qty`, `total_price`, `created_at`, `updated_at`) VALUES
	(1, 1, 1, NULL, 2, 12000.00, NULL, NULL),
	(2, 1, 1, NULL, 3, 13000.00, NULL, NULL),
	(3, 1, 1, NULL, 1, 10000.00, NULL, NULL),
	(4, 2, 2, NULL, 2, 15000.00, NULL, NULL),
	(5, 2, 2, NULL, 3, 30000.00, NULL, NULL),
	(6, 2, 2, NULL, 2, 20000.00, NULL, NULL),
	(7, 3, 3, NULL, 1, 10000.00, NULL, NULL),
	(8, 3, 3, NULL, 2, 20000.00, NULL, NULL),
	(9, 4, 3, NULL, 3, 30000.00, NULL, NULL),
	(10, 4, 3, NULL, 1, 10000.00, NULL, NULL),
	(11, 5, 2, NULL, 2, 20000.00, NULL, NULL),
	(12, 5, 2, NULL, 3, 30000.00, NULL, NULL);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.transaction_details
CREATE TABLE IF NOT EXISTS `transaction_details` (
  `transaction_id` int(11) DEFAULT NULL,
  `product_id` int(11) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `price` decimal(25,2) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `transaction_id` (`transaction_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `transaction_details_ibfk_1` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`),
  CONSTRAINT `transaction_details_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.transaction_details: ~9 rows (approximately)
/*!40000 ALTER TABLE `transaction_details` DISABLE KEYS */;
REPLACE INTO `transaction_details` (`transaction_id`, `product_id`, `status`, `qty`, `price`, `created_at`, `updated_at`) VALUES
	(1, 1, NULL, 1, NULL, NULL, NULL),
	(1, 1, NULL, 2, NULL, NULL, NULL),
	(1, 1, NULL, 3, NULL, NULL, NULL),
	(2, 2, NULL, 1, NULL, NULL, NULL),
	(2, 2, NULL, 2, NULL, NULL, NULL),
	(2, 2, NULL, 3, NULL, NULL, NULL),
	(3, 3, NULL, 1, NULL, NULL, NULL),
	(3, 3, NULL, 2, NULL, NULL, NULL),
	(3, 3, NULL, 3, NULL, NULL, NULL);
/*!40000 ALTER TABLE `transaction_details` ENABLE KEYS */;

-- Dumping structure for table alta_online_shop.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL,
  `names` varchar(255) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `gender` char(1) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table alta_online_shop.users: ~5 rows (approximately)
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
REPLACE INTO `users` (`id`, `names`, `status`, `dob`, `gender`, `created_at`, `updated_at`) VALUES
	(1, 'dedi', NULL, '2000-03-16', '1', NULL, NULL),
	(2, 'corbuzer', NULL, '2000-05-31', '1', NULL, NULL),
	(3, 'emma', NULL, '2000-10-09', '2', NULL, NULL),
	(4, 'watson', NULL, '2000-08-08', '2', NULL, NULL),
	(5, 'ilham', NULL, '2000-12-12', '1', NULL, NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
